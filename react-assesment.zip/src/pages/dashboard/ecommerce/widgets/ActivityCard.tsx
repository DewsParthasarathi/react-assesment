import React from "react";
import Highcharts from "highcharts";
import Chart from "../../../../components/ui/Chart";
import type { EcommerceActivity } from "../../../../api/types";

interface ActivityCardProps {
  data?: EcommerceActivity;
  isInsideSharedContainer?: boolean;
}

export const ActivityCard: React.FC<ActivityCardProps> = ({
  data,
  isInsideSharedContainer = false,
}) => {
  const title = data?.title || "Activity";
  const timeLabel = data?.timeLabel || "Last Week";
  const percentage = data?.percentage || "82%";
  const change = data?.change || "19.6%";
  const isUp = data?.changeDirection !== "down";
  const days = data?.days || ["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"];
  const seriesData = data?.series || [32, 22, 28, 20, 42, 26, 36];

  const chartOptions: Highcharts.Options = {
    chart: {
      type: "areaspline",
      height: 95,
      backgroundColor: "transparent",
      margin: [10, 0, 20, 0],
      spacing: [0, 0, 0, 0],
    },
    title: { text: undefined },
    credits: { enabled: false },
    legend: { enabled: false },
    tooltip: {
      backgroundColor: "#ffffff",
      borderColor: "#dbdade",
      borderRadius: 6,
      style: { fontSize: "11px", fontFamily: "Poppins" },
      pointFormat: "<b>{point.y}%</b> activity",
    },
    xAxis: {
      categories: days,
      lineWidth: 0,
      tickWidth: 0,
      labels: {
        style: {
          color: "#a5a3ae",
          fontSize: "10px",
          fontFamily: "Poppins",
        },
        y: 14,
      },
    },
    yAxis: {
      visible: false,
    },
    plotOptions: {
      areaspline: {
        lineWidth: 2,
        lineColor: "#71dd37",
        fillColor: {
          linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
          stops: [
            [0, "rgba(113, 221, 55, 0.28)"],
            [1, "rgba(113, 221, 55, 0.0)"],
          ],
        },
        marker: {
          enabled: false,
        },
      },
    },
    series: [
      {
        type: "areaspline",
        name: "Activity",
        data: seriesData,
      },
    ],
  };

  const containerClass = isInsideSharedContainer
    ? "p-5 flex flex-col justify-between h-full"
    : "bg-white rounded-[6px] p-5 shadow-[0_2px_4px_rgba(165,163,174,0.1)] border border-[#dbdade]/50 flex flex-col justify-between h-full min-h-[175px]";

  return (
    <div className={containerClass}>
      <div className="flex items-center justify-between">
        <h3 className="text-fs18 font-medium text-[#444050] tracking-tight">{title}</h3>
        <span className="text-fs13 text-[#a5a3ae]">{timeLabel}</span>
      </div>

      <div className="flex items-end justify-between mt-3">
        <div className="pb-1">
          <span className="text-fs24 font-bold text-[#444050] leading-none">
            {percentage}
          </span>
          <div
            className={`text-fs12 font-medium flex items-center gap-1 mt-1.5 ${
              isUp ? "text-[#71dd37]" : "text-[#ea5455]"
            }`}
          >
            <span>{isUp ? "↑" : "↓"}</span>
            <span>{change}</span>
          </div>
        </div>

        <div className="w-[140px] h-[95px]">
          <Chart options={chartOptions} />
        </div>
      </div>
    </div>
  );
};

export default ActivityCard;
