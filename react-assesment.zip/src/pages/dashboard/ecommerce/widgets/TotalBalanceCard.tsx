import React from "react";
import Highcharts from "highcharts";
import Chart from "../../../../components/ui/Chart";
import type { EcommerceTotalBalance } from "../../../../api/types";
import YearSelectionPopup from "../../../../components/ui/YearSelectionPopup";

interface TotalBalanceCardProps {
  data?: EcommerceTotalBalance;
  availableYears?: string[];
  selectedYear?: string;
  onSelectYear?: (year: string) => void;
}

export const TotalBalanceCard: React.FC<TotalBalanceCardProps> = ({
  data,
  availableYears = ["2023", "2022"],
  selectedYear = "2023",
  onSelectYear,
}) => {
  const title = data?.title || "Total Balance";
  const walletBalance = data?.walletBalance || "$2.54K";
  const paypalBalance = data?.paypalBalance || "$4.21K";
  const months = data?.months || ["Jan", "Feb", "Mar", "Apr", "May", "Jun"];
  const seriesData = data?.series || [18, 24, 20, 32, 18, 30];
  const salesGrowthMessage =
    data?.salesGrowthMessage || "You have done 57.6% more sales.";
  const subMessage =
    data?.subMessage || "check your new badge in your profile.";

  // Highlighting the last point with an orange circular marker
  const seriesPoints: Highcharts.PointOptionsObject[] = seriesData.map(
    (val, idx, arr) =>
      idx === arr.length - 1
        ? {
            y: val,
            marker: {
              enabled: true,
              radius: 5,
              fillColor: "#ffffff",
              lineColor: "#ffab00",
              lineWidth: 2.5,
            },
          }
        : {
            y: val,
            marker: { enabled: false },
          },
  );

  const chartOptions: Highcharts.Options = {
    chart: {
      type: "spline",
      height: 125,
      backgroundColor: "transparent",
      margin: [15, 10, 25, 10],
      spacing: [0, 0, 0, 0],
    },
    title: { text: undefined },
    credits: { enabled: false },
    legend: { enabled: false },
    tooltip: {
      backgroundColor: "#ffffff",
      borderColor: "#dbdade",
      borderRadius: 6,
      style: { fontSize: "11px", fontFamily: "Poppins" },
      valuePrefix: "$",
      valueSuffix: "k",
    },
    xAxis: {
      categories: months,
      lineWidth: 0,
      tickWidth: 0,
      labels: {
        style: {
          color: "#a5a3ae",
          fontSize: "11px",
          fontFamily: "Poppins",
        },
        y: 18,
      },
    },
    yAxis: {
      visible: false,
    },
    plotOptions: {
      spline: {
        lineWidth: 3,
        color: "#ffab00",
        shadow: {
          color: "rgba(255, 171, 0, 0.35)",
          width: 8,
          offsetX: 0,
          offsetY: 4,
        },
      },
    },
    series: [
      {
        type: "spline",
        name: "Balance",
        data: seriesPoints,
      },
    ],
  };

  return (
    <div className="bg-white rounded-[6px] p-5 shadow-[0_2px_4px_rgba(165,163,174,0.1)] border border-[#dbdade]/50 flex flex-col justify-between h-full min-h-[340px]">
      <div>
        <div className="flex items-center justify-between">
          <h3 className="text-fs18 font-bold text-[#444050] tracking-tight">
            {title}
          </h3>

          <YearSelectionPopup
            selectedYear={selectedYear}
            onSelectYear={onSelectYear || (() => {})}
            availableYears={availableYears}
          >
            <button
              type="button"
              className="text-[#a5a3ae] hover:text-[#5d596c] p-1 rounded transition cursor-pointer"
              aria-label="Balance options"
            >
              <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                <circle cx="12" cy="5" r="2" />
                <circle cx="12" cy="12" r="2" />
                <circle cx="12" cy="19" r="2" />
              </svg>
            </button>
          </YearSelectionPopup>
        </div>

        {/* Balance summaries */}
        <div className="flex items-center gap-6 mt-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-[6px] bg-[#fff1e3] text-[#ffab00] flex items-center justify-center shrink-0">
              <svg
                className="w-5 h-5"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={1.8}
                  d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"
                />
              </svg>
            </div>
            <div>
              <span className="text-fs16 font-bold text-[#444050] block leading-tight">
                {walletBalance}
              </span>
              <span className="text-fs12 text-[#a5a3ae] block leading-tight mt-0.5">
                Wallet
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-[6px] bg-[#f5f5f9] text-[#a5a3ae] flex items-center justify-center shrink-0 font-bold text-fs16">
              $
            </div>
            <div>
              <span className="text-fs16 font-bold text-[#444050] block leading-tight">
                {paypalBalance}
              </span>
              <span className="text-fs12 text-[#a5a3ae] block leading-tight mt-0.5">
                Paypal
              </span>
            </div>
          </div>
        </div>
      </div>

      <div className="w-full h-[125px] my-1">
        <Chart options={chartOptions} />
      </div>

      {/* Footer message with action button */}
      <div className="border-t border-[#dbdade]/40 pt-3 flex items-center justify-between mt-auto">
        <div>
          <span className="text-fs12 font-medium text-[#6f6b7d] block leading-tight">
            {salesGrowthMessage}
          </span>
          <span className="text-fs11 text-[#a5a3ae] block leading-tight mt-0.5 capitalize">
            {subMessage}
          </span>
        </div>

        <button
          type="button"
          className="w-8 h-8 rounded-[6px] bg-[#fff1e3] text-[#ffab00] flex items-center justify-center hover:bg-[#ffe5c9] transition cursor-pointer shrink-0 ml-2"
          aria-label="View sales details"
        >
          <svg
            className="w-4 h-4"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M9 5l7 7-7 7"
            />
          </svg>
        </button>
      </div>
    </div>
  );
};

export default TotalBalanceCard;

