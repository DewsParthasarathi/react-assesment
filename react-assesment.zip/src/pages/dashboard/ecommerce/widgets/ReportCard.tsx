import React from "react";
import type { EcommerceReport } from "../../../../api/types";
import YearSelectionPopup from "../../../../components/ui/YearSelectionPopup";

interface ReportCardProps {
  data?: EcommerceReport;
  availableYears?: string[];
  selectedYear?: string;
  onSelectYear?: (year: string) => void;
  isInsideSharedContainer?: boolean;
}

export const ReportCard: React.FC<ReportCardProps> = ({
  data,
  availableYears = ["2023", "2022"],
  selectedYear = "2023",
  onSelectYear,
  isInsideSharedContainer = false,
}) => {
  const title = data?.title || "Report";
  const subtitle = data?.subtitle || "Monthly Avg $45,578k";
  const items = data?.items || [
    {
      label: "Income",
      amount: "$42,845",
      change: "+2.7k",
      changeType: "positive" as const,
      type: "income" as const,
    },
    {
      label: "Expense",
      amount: "$38,658",
      change: "-1.15k",
      changeType: "negative" as const,
      type: "expense" as const,
    },
    {
      label: "Profit",
      amount: "$18,220",
      change: "+1.34k",
      changeType: "positive" as const,
      type: "profit" as const,
    },
  ];

  const containerClass = isInsideSharedContainer
    ? "p-5 flex flex-col justify-between h-full"
    : "bg-white rounded-[6px] p-5 shadow-[0_2px_4px_rgba(165,163,174,0.1)] border border-[#dbdade]/50 flex flex-col justify-between h-full min-h-[260px]";

  return (
    <div className={containerClass}>
      <div className="flex items-start justify-between">
        <div>
          <h3 className="text-fs18 font-bold text-[#444050] tracking-tight">{title}</h3>
          <p className="text-fs12 text-[#a5a3ae] mt-0.5">{subtitle}</p>
        </div>

        <YearSelectionPopup
          selectedYear={selectedYear}
          onSelectYear={onSelectYear || (() => {})}
          availableYears={availableYears}
        >
          <button
            type="button"
            className="text-[#a5a3ae] hover:text-[#5d596c] p-1 rounded transition cursor-pointer"
            aria-label="Report options"
          >
            <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
              <circle cx="12" cy="5" r="2" />
              <circle cx="12" cy="12" r="2" />
              <circle cx="12" cy="19" r="2" />
            </svg>
          </button>
        </YearSelectionPopup>
      </div>

      <div className="space-y-4 my-auto pt-3">
        {items.map((item, idx) => {
          const isIncome = item.type === "income";
          const isExpense = item.type === "expense";
          const isProfit = item.type === "profit";

          const iconBg = isIncome
            ? "bg-[#ffebe6] text-[#ea5455]"
            : isExpense
            ? "bg-[#e7e7ff] text-[#696cff]"
            : "bg-[#e8fadf] text-[#71dd37]";

          const badgeBg =
            item.changeType === "positive"
              ? "bg-[#e8fadf] text-[#71dd37]"
              : "bg-[#ffebe6] text-[#ea5455]";

          return (
            <div key={idx} className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div
                  className={`w-9 h-9 rounded-[6px] flex items-center justify-center shrink-0 font-bold ${iconBg}`}
                >
                  {isIncome && <span className="text-fs15 font-bold font-sans">P</span>}
                  {isExpense && (
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"
                      />
                    </svg>
                  )}
                  {isProfit && <span className="text-fs15 font-bold">$</span>}
                </div>

                <div>
                  <span className="text-fs13 text-[#a5a3ae] block leading-none capitalize">
                    {item.label}
                  </span>
                  <span className="text-fs15 font-bold text-[#444050] block mt-1 leading-none">
                    {item.amount}
                  </span>
                </div>
              </div>

              <span
                className={`text-fs11 font-medium px-2 py-0.5 rounded tracking-tight ${badgeBg}`}
              >
                {item.change}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default ReportCard;
