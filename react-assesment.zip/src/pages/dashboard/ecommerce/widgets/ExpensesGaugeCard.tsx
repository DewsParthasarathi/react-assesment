import React from "react";
import Highcharts from "highcharts";
import Chart from "../../../../components/ui/Chart";
import type { EcommerceExpensesGauge } from "../../../../api/types";

interface ExpensesGaugeCardProps {
  data?: EcommerceExpensesGauge;
}

export const ExpensesGaugeCard: React.FC<ExpensesGaugeCardProps> = ({ data }) => {
  const title = data?.title || "Expenses";
  const percentage = data?.percentage ?? 72;
  const comparisonText =
    data?.comparisonText || "$2k expenses more than last month";

  const chartOptions: Highcharts.Options = {
    chart: {
      type: "pie",
      height: 90,
      backgroundColor: "transparent",
      margin: [0, 0, 0, 0],
      spacing: [0, 0, 0, 0],
    },
    title: { text: undefined },
    credits: { enabled: false },
    tooltip: { enabled: false },
    plotOptions: {
      pie: {
        startAngle: -100,
        endAngle: 100,
        center: ["50%", "85%"],
        size: "150%",
        innerSize: "78%",
        borderWidth: 0,
        dataLabels: { enabled: false },
        states: {
          hover: {
            halo: { size: 0 },
          },
        },
      },
    },
    series: [
      {
        type: "pie",
        name: "Expenses",
        data: [
          {
            name: "Expenses",
            y: percentage,
            color: "#696cff",
          },
          {
            name: "Remaining",
            y: 100 - percentage,
            color: "#ebe9f1",
          },
        ],
      },
    ],
  };

  return (
    <div className="bg-white rounded-[6px] p-5 shadow-[0_2px_4px_rgba(165,163,174,0.1)] border border-[#dbdade]/50 flex flex-col justify-between h-full min-h-[175px]">
      <div>
        <span className="text-fs14 font-medium text-[#6f6b7d]">{title}</span>
      </div>

      <div className="relative w-full h-[75px] flex items-center justify-center my-auto">
        <Chart options={chartOptions} />
        <div className="absolute inset-0 flex items-end justify-center pb-0 pointer-events-none">
          <span className="text-fs18 font-bold text-[#444050] leading-none mb-1">
            {percentage}%
          </span>
        </div>
      </div>

      <div className="text-center mt-1">
        <p className="text-fs12 text-[#a5a3ae] leading-snug">
          {comparisonText}
        </p>
      </div>
    </div>
  );
};

export default ExpensesGaugeCard;

