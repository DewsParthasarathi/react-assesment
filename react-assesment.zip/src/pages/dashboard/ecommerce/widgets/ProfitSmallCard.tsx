import React from "react";
import Highcharts from "highcharts";
import Chart from "../../../../components/ui/Chart";
import type { EcommerceProfitSmall } from "../../../../api/types";

interface ProfitSmallCardProps {
  data?: EcommerceProfitSmall;
}

export const ProfitSmallCard: React.FC<ProfitSmallCardProps> = ({ data }) => {
  const title = data?.title || "Profit";
  const value = data?.value || "624K";
  const months = data?.months || ["Jan", "Apr", "Jul", "Oct"];
  const seriesData = data?.series || [38, 22, 54, 76];

  const chartOptions: Highcharts.Options = {
    chart: {
      type: "column",
      height: 90,
      backgroundColor: "transparent",
      margin: [10, 0, 20, 0],
      spacing: [0, 0, 0, 0],
    },
    title: { text: undefined },
    credits: { enabled: false },
    legend: { enabled: false },
    tooltip: {
      backgroundColor: "#ffffff",
      borderColor: "#dbdade",
      borderRadius: 6,
      style: { fontSize: "11px", fontFamily: "Poppins" },
      pointFormat: "<b>{point.y}K</b> profit",
    },
    xAxis: {
      categories: months,
      lineWidth: 0,
      tickWidth: 0,
      labels: {
        style: {
          color: "#a5a3ae",
          fontSize: "10px",
          fontFamily: "Poppins",
        },
        y: 14,
      },
    },
    yAxis: {
      visible: false,
      min: 0,
    },
    plotOptions: {
      column: {
        color: "#71dd37",
        borderRadius: 4,
        pointWidth: 6,
        borderWidth: 0,
      },
    },
    series: [
      {
        type: "column",
        name: "Profit",
        data: seriesData,
      },
    ],
  };

  return (
    <div className="bg-white rounded-[6px] p-5 shadow-[0_2px_4px_rgba(165,163,174,0.1)] border border-[#dbdade]/50 flex flex-col justify-between h-full min-h-[175px]">
      <div>
        <span className="text-fs14 font-medium text-[#6f6b7d]">{title}</span>
        <div className="text-fs22 font-bold text-[#444050] mt-0.5 leading-tight">
          {value}
        </div>
      </div>

      <div className="w-full h-[90px] mt-2">
        <Chart options={chartOptions} />
      </div>
    </div>
  );
};

export default ProfitSmallCard;

