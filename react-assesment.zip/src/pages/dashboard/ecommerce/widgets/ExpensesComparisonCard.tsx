import React from "react";
import Highcharts from "highcharts";
import Chart from "../../../../components/ui/Chart";
import type { EcommerceExpensesComparison } from "../../../../api/types";

interface ExpensesComparisonCardProps {
  data?: EcommerceExpensesComparison;
}

export const ExpensesComparisonCard: React.FC<ExpensesComparisonCardProps> = ({
  data,
}) => {
  const title = data?.title || "Expenses";
  const value = data?.value || "$84.7K";
  const growth = data?.growth || "28.14%";
  const period = data?.period || "JULY 2023";
  const series = data?.series || [
    {
      name: "positive",
      data: [28, 12, 35, 42, 18, 25, 30, 22, 19],
    },
    {
      name: "negative",
      data: [-15, -8, -12, -20, -10, -16, -14, -18, -12],
    },
  ];

  const chartOptions: Highcharts.Options = {
    chart: {
      type: "column",
      height: 100,
      backgroundColor: "transparent",
      margin: [5, 0, 5, 0],
      spacing: [0, 0, 0, 0],
    },
    title: { text: undefined },
    credits: { enabled: false },
    legend: { enabled: false },
    tooltip: {
      backgroundColor: "#ffffff",
      borderColor: "#dbdade",
      borderRadius: 6,
      style: { fontSize: "11px", fontFamily: "Poppins" },
      pointFormat: "<b>{point.y}k</b>",
    },
    xAxis: {
      visible: false,
    },
    yAxis: {
      visible: false,
      gridLineWidth: 0,
    },
    plotOptions: {
      column: {
        pointPadding: 0.15,
        groupPadding: 0.1,
        borderRadius: 3,
        borderWidth: 0,
        pointWidth: 4,
      },
    },
    series: [
      {
        type: "column",
        name: "Positive",
        color: "#696cff",
        data: series[0]?.data || [28, 12, 35, 42, 18, 25, 30, 22, 19],
      },
      {
        type: "column",
        name: "Negative",
        color: "#ff9f43",
        data: series[1]?.data || [-15, -8, -12, -20, -10, -16, -14, -18, -12],
      },
    ],
  };

  return (
    <div className="bg-white rounded-[6px] p-5 shadow-[0_2px_4px_rgba(165,163,174,0.1)] border border-[#dbdade]/50 flex flex-col justify-between h-full min-h-[160px]">
      <div className="flex items-center justify-between">
        <div>
          <span className="text-fs16 font-semibold text-[#444050]">{title}</span>
          <div className="text-fs22 font-bold text-[#444050] mt-0.5 leading-tight">
            {value}
          </div>
          <div className="text-fs12 font-medium text-[#71dd37] flex items-center gap-1 mt-1">
            <span>↑</span>
            <span>{growth}</span>
          </div>
        </div>

        <div className="w-[150px] h-[100px]">
          <Chart options={chartOptions} />
        </div>
      </div>

      <div className="mt-2">
        <span className="bg-[#f5f5f9] text-[#a5a3ae] text-fs11 font-medium px-2.5 py-1 rounded tracking-wider uppercase inline-block">
          {period}
        </span>
      </div>
    </div>
  );
};

export default ExpensesComparisonCard;

