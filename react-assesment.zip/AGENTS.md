# Code Modification & Approval Policy

## 1. Explicit Approval Required Before Code Changes
- **Never modify project code directly without the user's explicit confirmation.**
- Before invoking file modification tools (`replace_file_content`, `multi_replace_file_content`, `write_to_file`) or running destructive commands, the assistant MUST:
  1. Clearly explain the proposed solution and specify which files will be affected.
  2. Show the proposed diff or code snippets to the user for review.
  3. Solicit the user's approval before modifying any files on disk.

## 2. Interactive Confirmation Flow
- Present an interactive confirmation to the user using the `ask_question` tool with choices:
  - "(Recommended) Accept changes and apply to project"
  - "Reject changes (leave files untouched)"
- **If accepted**: Proceed to execute the file modifications and verify them.
- **If rejected**: Discard the proposed changes immediately and keep all project files unchanged.

## 3. Planning Workflow
- For multi-step tasks or non-trivial refactoring, propose a plan first so the user can review and approve it before execution begins.
